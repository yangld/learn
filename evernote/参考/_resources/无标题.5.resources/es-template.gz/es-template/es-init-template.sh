# 初始化elasticsearch 模板脚本
# curl 返回200 ok表明设置成功
curl -i -XPOST 'localhost:9200/_template/mag_log_template?include_type_name=true' -H 'Content-Type: application/json' -d"@mag-log-template.json"
curl -i -XPOST 'localhost:9200/_template/uni_auth_log_template?include_type_name=true' -H 'Content-Type: application/json' -d"@uni-auth-log-template.json"
curl -i -XPOST 'localhost:9200/_template/pekall_log_default_template?pretty&include_type_name=true' -H 'Content-Type: application/json' -d"@pekall-log-default-template.json"
curl -i -XPOST 'localhost:9200/_template/cmc_log_default_template1?pretty&include_type_name=true' -H 'Content-Type: application/json' -d"@cmc-log-default-template1.json"
curl -i -XPOST 'localhost:9200/_template/cmc_log_default_template2?pretty&include_type_name=true' -H 'Content-Type: application/json' -d"@cmc-log-default-template2.json"

请按照以下示例使用ios创建脚本，支持两个参数
  第一个参数为必选项，输入要部署的服务器的域名或外网ip；
  第二个参数为非必选项目，不输入时默认使用"pekallsu"作为密码，对密码有其他要求时请输入：

$./create_server_key_noprompt.sh 192.168.8.74
$./create_server_key_noprompt.sh 192.168.8.74 passwd

运行结果：
1. Creating the Web Server private key and certificate request
 ** For 'Common Name' enter your server's IP address **

Generating RSA private key, 2048 bit long modulus
................................................+++
.............+++
e is 65537 (0x10001)

2. Signing the server key with the CA. You'll the CA passphrase from step 1.

Signature ok
subject=/C=CN/ST=Beijing/L=Beijing/O=Pekall Ltd/OU=Pekall/CN=192.168.8.74/emailAddress=support@pekall.com
Getting CA Private Key

3. Using keytool put key and certificates into file keystore

证书已添加到密钥库中
已成功导入别名 1 的条目。
已完成导入命令: 1 个条目成功导入, 0 个条目失败或取消


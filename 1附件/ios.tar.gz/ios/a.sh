#! /bin/bash


if [ $# -lt 1 ];then
echo "Usage: ./create_server_key.sh commonName(DOMAIN or WAN_IP)"
exit 0
fi

passwd="pekallsu"

if [ $# -eq 2 ] ;then
    passwd=$2
fi

#modify openssl_req.cnf's commonName 
sed -i "s/commonName = .*/commonName =  $1/" openssl_req.cnf
sed -i "s/challengePassword = .*/challengePassword = $passwd/" openssl_req.cnf

rm -rf server.key
rm -rf server.csr
rm -rf server.crt
rm -rf server.pkcs12
rm -rf cacert.srl
rm -rf keystore

source /etc/profile

echo ""
echo "1. Creating the Web Server private key and certificate request"
echo " ** For 'Common Name' enter your server's IP address **"
echo ""

openssl genrsa 2048 > server.key

#openssl req -new -key server.key -out server.csr
#openssl req -new -key server.key -out server.csr -subj "/C=CN/ST=Beijing/L=Beijing/O=Pekall Ltd/OU=Pekall/CN=192.168.8.74/emailAddress=support@pekall.com"
openssl req -new -key server.key -out server.csr -config openssl_req.cnf

echo ""
echo "2. Signing the server key with the CA. You'll the CA passphrase from step 1."
echo ""
#openssl x509 -req -days 365 -in server.csr -CA cacert.crt -CAkey cakey.key -CAcreateserial -out server.crt -extensions ssl_server
openssl x509 -req -days 365 -in server.csr -CA cacert.crt -CAkey cakey.key -passin pass:$passwd -CAcreateserial -out server.crt -extensions ssl_server
#openssl pkcs12 -inkey server.key -in server.crt -export -out server.pkcs12
openssl pkcs12 -inkey server.key -in server.crt -export -CAfile cacert.crt -chain -password pass:$passwd -out server.pkcs12

openssl genrsa 2048 > client.key




echo ""
echo "3. Using keytool put key and certificates into file keystore"
echo ""
#keytool -keystore keystore -import -alias server0 -file server.crt -trustcacerts
keytool -keystore keystore -import -alias server -file server.crt -storepass $passwd -trustcacerts -noprompt
#keytool -importkeystore -srckeystore server.pkcs12 -srcstoretype PKCS12 -destkeystore keystore
keytool -importkeystore -srckeystore server.pkcs12 -srcstorepass $passwd -srcstoretype PKCS12 -destkeystore keystore -deststorepass ${passwd} -noprompt

keytool -changealias -v -alias 1 -destalias localhost -keystore keystore -storepass ${passwd}
exit 0
